-- Create a sample table
CREATE TABLE employees (
    id INTEGER PRIMARY KEY,
    name TEXT,
    department TEXT,
    salary INTEGER,
    hire_date DATE
);

-- Insert sample data
INSERT INTO employees (name, department, salary, hire_date) VALUES
('Amit Sharma', 'IT', 60000, '2022-01-15'),
('Priya Singh', 'HR', 50000, '2021-03-12'),
('Rahul Verma', 'Finance', 70000, '2020-07-30'),
('Sneha Gupta', 'IT', 65000, '2023-02-25'),
('Arjun Patel', 'Marketing', 55000, '2022-06-10');
