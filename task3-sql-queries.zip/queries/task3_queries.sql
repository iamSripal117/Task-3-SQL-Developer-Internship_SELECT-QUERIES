-- 1. Select all columns
SELECT * FROM employees;

-- 2. Select specific columns
SELECT name, salary FROM employees;

-- 3. Filter rows with WHERE
SELECT * FROM employees WHERE department = 'IT';

-- 4. Using AND & OR
SELECT * FROM employees WHERE department = 'IT' AND salary > 60000;
SELECT * FROM employees WHERE department = 'HR' OR salary < 55000;

-- 5. Using LIKE
SELECT * FROM employees WHERE name LIKE '%Singh%';

-- 6. Using BETWEEN
SELECT * FROM employees WHERE salary BETWEEN 55000 AND 65000;

-- 7. Sort with ORDER BY
SELECT * FROM employees ORDER BY salary DESC;

-- 8. LIMIT output
SELECT * FROM employees ORDER BY salary DESC LIMIT 3;

-- 9. Difference between = and IN
SELECT * FROM employees WHERE department = 'IT';
SELECT * FROM employees WHERE department IN ('IT', 'HR');

-- 10. Aliasing
SELECT name AS Employee_Name, salary AS Monthly_Salary FROM employees;

-- 11. DISTINCT values
SELECT DISTINCT department FROM employees;

-- 12. Default sort order (ASC)
SELECT * FROM employees ORDER BY name; -- ascending by default
